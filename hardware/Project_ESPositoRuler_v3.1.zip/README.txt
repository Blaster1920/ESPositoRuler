An ESP32-PICO-V3 powered ruler with an onboard accelerometer.
It can be powered from both USB and a 1s LiPo battery using the dedicated connector.
Suggested 1s 500mAh drone battery repurposed. The connector is a standard JST-XH 2 pins.



```
DISCLAIMER:
This is a DIY project. DO IT AT YOUR OWN RISK! I am not responsible for any dead device, waste of money, your cat dying, You getting fired from work because your ESP32 based alarm failed OR your ruler causing a global total thermonuclear war.
```

Copyright Addittiverse 2020.
This source describes Open Hardware and is licensed under the CERN-OHL-S v2
You may redistribute and modify this documentation and make products using it
under the terms of the CERN-OHL-S v2 (https:/cern.ch/cern-ohl).
This documentation is distributed WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING OF MERCHANTABILITY, SATISFACTORY QUALITY AND FITNESS FOR A PARTICULAR PURPOSE.
Please see the CERN-OHL-S v2 for applicable conditions.
Source location: https://github.com/Blaster1920/ESPositoRuler
As per CERN-OHL-S v2 section 4, should You produce hardware based on these sources,
You must maintain the Source Location visible on the PCB of the ESPositoRuler or other product you make using this documentation.            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。